class AppImages {
  static const String _baseUrl = 'assets/images/';

  static const faceNet = '${_baseUrl}face_net.png';
}
